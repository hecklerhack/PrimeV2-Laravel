<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Industry extends Model
{
    //
    public $table = 'tbl_industry';
    public $primaryKey = 'id';
    public $timestamps = false;
}
