<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Candidate_Achieve extends Model
{
    //
    protected $table = 'candidate_achieve';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
