<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Candidate_Educ extends Model
{
    //
    protected $table = 'candidate_educ';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
