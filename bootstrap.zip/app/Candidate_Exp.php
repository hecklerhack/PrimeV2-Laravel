<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Candidate_Exp extends Model
{
    //
    protected $table = 'candidate_exp';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
