<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Latest_Position extends Model
{
    protected $table = 'position';
    protected $primaryKey = 'id';
}
