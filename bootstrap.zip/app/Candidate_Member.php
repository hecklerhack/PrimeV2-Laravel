<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Candidate_Member extends Model
{
    //
    protected $table = 'candidate_member';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
