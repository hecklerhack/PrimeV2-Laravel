<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Educ_attainment extends Model
{
    protected $table = 'educ_attainment';
    protected $primaryKey = 'id';
}
