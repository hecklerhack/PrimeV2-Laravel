@extends('layouts.app')
    @section('content')
       <h1>{{$title1}}</h1>
       <p>This is the about page</p>
    @endsection